# !bin/sh

rm airtos.tar.gz
tar -czvf airtos.tar.gz .\


# extract => tar -xvf airtos.tar.gz